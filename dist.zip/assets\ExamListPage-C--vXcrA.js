import{u as S,j as n,a as y}from"./index-UwvWstiG.js";import{a as w}from"./ui-vendor-iwsQliNP.js";import{u as _}from"./useFetch-D0x9LvNw.js";import{B as j}from"./Button-C6ObaOK3.js";import"./data-vendor-B_fJaFFy.js";const k=async()=>{if(window._edu_pdf_libs_loaded)return window._edu_pdf_libs_loaded;const o=c=>new Promise((i,d)=>{const r=document.createElement("script");r.src=c,r.async=!0,r.onload=()=>i(),r.onerror=()=>d(new Error("Failed to load "+c)),document.head.appendChild(r)});await Promise.all([o("https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js"),o("https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js")]);const a=window.jspdf?.jsPDF||window.jsPDF||window.jspdf&&window.jspdf.default&&window.jspdf.default.jsPDF;return window._edu_pdf_libs_loaded={jsPDF:a,html2canvas:window.html2canvas},window._edu_pdf_libs_loaded},D=async(o,p,x="EduMath")=>{try{const a=await k(),{jsPDF:c,html2canvas:i}=a,d=P(o,p,x);document.body.appendChild(d);const r=await i(d,{scale:2,useCORS:!0,logging:!1,backgroundColor:"#ffffff"}),f=r.toDataURL("image/png"),u=new c({orientation:"portrait",unit:"mm",format:"a4"}),t=u.internal.pageSize.getWidth(),e=u.internal.pageSize.getHeight(),s=t,l=r.height*t/r.width;let m=l,g=0;for(u.addImage(f,"PNG",0,g,s,l),m-=e;m>0;)g=m-l,u.addPage(),u.addImage(f,"PNG",0,g,s,l),m-=e;const h=`${o.title.replace(/[^a-zA-Z0-9]/g,"_")}_${new Date().toISOString().split("T")[0]}.pdf`;return u.save(h),document.body.removeChild(d),{success:!0,fileName:h}}catch(a){return console.error("❌ PDF oluşturma hatası:",a),{success:!1,error:a.message}}},P=(o,p,x)=>{const a=document.createElement("div");a.style.cssText=`
        position: absolute;
        left: -9999px;
        width: 210mm;
        padding: 20mm;
        background: white;
        font-family: Arial, sans-serif;
        color: #000;
    `;const c=new Date().toLocaleDateString("tr-TR",{year:"numeric",month:"long",day:"numeric"});return a.innerHTML=`
        <style>
            .exam-print {
                font-size: 12pt;
                line-height: 1.6;
            }
            .exam-header {
                text-align: center;
                border-bottom: 3px solid #000;
                padding-bottom: 15px;
                margin-bottom: 25px;
            }
            .exam-title {
                font-size: 20pt;
                font-weight: bold;
                margin-bottom: 8px;
            }
            .exam-info {
                display: flex;
                justify-content: space-between;
                margin-bottom: 20px;
                font-size: 10pt;
                border: 1px solid #ddd;
                padding: 10px;
                background: #f9f9f9;
            }
            .question-block {
                margin-bottom: 25px;
                page-break-inside: avoid;
            }
            .question-header {
                font-weight: bold;
                margin-bottom: 10px;
                font-size: 11pt;
                display: flex;
                justify-content: space-between;
            }
            .question-text {
                margin-bottom: 12px;
                padding: 10px;
                background: #f5f5f5;
                border-left: 3px solid #4F46E5;
            }
            .options {
                margin-left: 20px;
            }
            .option {
                margin-bottom: 8px;
                display: flex;
                align-items: baseline;
            }
            .option-letter {
                font-weight: bold;
                margin-right: 8px;
                min-width: 25px;
            }
            .answer-space {
                margin-top: 15px;
                padding: 10px;
                border: 1px dashed #999;
                min-height: 60px;
            }
            .student-info {
                display: flex;
                justify-content: space-between;
                margin-bottom: 20px;
                border: 2px solid #000;
                padding: 15px;
            }
            .info-field {
                font-size: 11pt;
                border-bottom: 1px solid #000;
                min-width: 200px;
                display: inline-block;
                margin-left: 10px;
            }
            .footer {
                margin-top: 30px;
                text-align: center;
                font-size: 9pt;
                color: #666;
                border-top: 1px solid #ddd;
                padding-top: 10px;
            }
        </style>

        <div class="exam-print">
            <!-- Header -->
            <div class="exam-header">
                <div style="font-size: 14pt; font-weight: bold; color: #4F46E5;">📐 EduMath - Matematik Değerlendirme Platformu</div>
                <div class="exam-title">${o.title}</div>
                <div style="font-size: 11pt; color: #666;">${o.description||""}</div>
            </div>

            <!-- Student Info -->
            <div class="student-info">
                <div>
                    <strong>👤 Ad Soyad:</strong>
                    <span class="info-field"></span>
                </div>
                <div>
                    <strong>🔢 Numara:</strong>
                    <span class="info-field"></span>
                </div>
                <div>
                    <strong>📅 Tarih:</strong>
                    <span class="info-field">${c}</span>
                </div>
            </div>

            <!-- Exam Info -->
            <div class="exam-info">
                <div><strong>Soru Sayısı:</strong> ${p.length}</div>
                <div><strong>Süre:</strong> ${o.duration} dakika</div>
                <div><strong>Hazırlayan:</strong> ${x}</div>
            </div>

            <!-- Questions -->
            ${p.map((i,d)=>`
                <div class="question-block">
                    <div class="question-header">
                        <span>📝 Soru ${d+1}</span>
                        <span>${i.points||10} Puan</span>
                    </div>
                    <div class="question-text">
                        ${i.question_text}
                    </div>

                    ${i.option_a?`
                        <div class="options">
                            <div class="option">
                                <span class="option-letter">A)</span>
                                <span>${i.option_a}</span>
                            </div>
                            <div class="option">
                                <span class="option-letter">B)</span>
                                <span>${i.option_b}</span>
                            </div>
                            <div class="option">
                                <span class="option-letter">C)</span>
                                <span>${i.option_c}</span>
                            </div>
                            <div class="option">
                                <span class="option-letter">D)</span>
                                <span>${i.option_d}</span>
                            </div>
                        </div>
                    `:`
                        <div class="answer-space">
                            <strong>Cevap:</strong>
                        </div>
                    `}
                </div>
            `).join("")}

            <!-- Footer -->
            <div class="footer">
                <p><strong>BAŞARILAR DİLERİZ! 🎓</strong></p>
                <p>Bu sınav EduMath platformu ile oluşturulmuştur. ${c}</p>
            </div>
        </div>
    `,a},R=()=>{const o=S();w.useEffect(()=>{try{const t=localStorage.getItem("edumath_user"),e=t?JSON.parse(t):null,s=e?.role||(e?.role_id===2?"teacher":e?.role_id===3?"student":void 0);(!s||s!=="teacher")&&o("/student-exams")}catch{o("/login")}},[o]);const{data:p,loading:x,error:a,refetch:c}=_("/exams"),[i,d]=w.useState(null),r=t=>{const e=String(t?.status||"").toLocaleLowerCase("tr-TR");return Number(t?.is_published)===1||e==="published"||e==="archived"?{key:"finished",label:"✅ Sınav Bitmiş (Yayınlandı)",color:"#2e7d32"}:Number(t?.total_questions||0)>0||e&&e!=="draft"?{key:"in-progress",label:"🟡 Henüz Bitmemiş (Hazırlanıyor)",color:"#b26a00"}:{key:"draft",label:"📝 Taslak",color:"#0f766e"}},f=async t=>{if(window.confirm("Bu sınavı ve içindeki tüm soruları silmek istediğinize emin misiniz?"))try{const e=await y.delete(`/exams/${t}`);c();const s=e?.data?.message||"Sınav silindi.";alert(s)}catch(e){alert(e?.response?.data?.error||"Silme işlemi başarısız.")}},u=async t=>{d(t);try{const[e,s]=await Promise.all([y.get(`/exams/${t}`),y.get(`/exams/${t}/questions`)]),l=e.data.data||e.data,m=s.data.data||s.data;if(!m||m.length===0){alert("❌ Bu sınavda henüz soru bulunmuyor!");return}let g={};try{const v=localStorage.getItem("edumath_user");g=v?JSON.parse(v):{}}catch{g={}}const h=g.full_name||g.name||"EduMath Öğretmeni",b=await D(l,m,h);b.success?alert(`✅ PDF başarıyla indirildi: ${b.fileName}`):alert(`❌ PDF oluşturma hatası: ${b.error}`)}catch(e){console.error("❌ PDF export hatası:",e),alert("PDF oluşturulurken bir hata oluştu!")}finally{d(null)}};return x?n.jsx("div",{style:{textAlign:"center",marginTop:"40px"},children:"Yükleniyor..."}):a?n.jsxs("div",{style:{textAlign:"center",marginTop:"40px",color:"#e74c3c"},children:["Hata: ",a]}):n.jsxs("div",{style:{maxWidth:"1000px",margin:"40px auto",padding:"20px",fontFamily:"Segoe UI"},children:[n.jsxs("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"30px"},children:[n.jsx("h2",{style:{color:"#2c3e50",margin:0},children:"📂 Sınavlarım"}),n.jsxs("div",{style:{display:"flex",gap:"10px"},children:[n.jsx(j,{onClick:()=>o("/exams/level-thresholds"),className:"flex items-center gap-2",children:"🎯 Seviye Eşikleri"}),n.jsx(j,{onClick:()=>o("/create-exam"),className:"flex items-center gap-2",children:"➕ Yeni Sınav Oluştur"})]})]}),n.jsx("div",{style:{display:"grid",gap:"15px"},children:(p||[]).length===0?n.jsx("p",{style:{textAlign:"center",color:"#7f8c8d",fontSize:"18px",marginTop:"50px"},children:"Henüz hiç sınav oluşturmadınız."}):(p||[]).map(t=>(()=>{const e=t.exam_id||t.id,s=r(t),l=s.key==="finished";return n.jsxs("div",{style:{backgroundColor:"white",padding:"20px",borderRadius:"10px",boxShadow:"0 2px 5px rgba(0,0,0,0.05)",border:"1px solid #eee",display:"flex",justifyContent:"space-between",alignItems:"center"},children:[n.jsxs("div",{children:[n.jsx("h3",{style:{margin:"0 0 5px 0",color:"#34495e"},children:t.title}),n.jsxs("p",{style:{margin:0,color:"#7f8c8d",fontSize:"14px"},children:["⏳ ",t.duration_minutes," Dakika • 📅 ",new Date(t.created_at).toLocaleDateString("tr-TR")]}),n.jsx("p",{style:{margin:"6px 0 0 0",fontSize:"12px",color:s.color,fontWeight:"bold"},children:s.label})]}),n.jsxs("div",{style:{display:"flex",gap:"10px"},children:[n.jsx("button",{onClick:()=>o(l?`/exams/${e}`:`/add-questions/${e}`),style:{backgroundColor:"#3498db",color:"white",border:"none",padding:"8px 15px",borderRadius:"5px",cursor:"pointer",fontWeight:"bold"},children:l?"👁️ Sınavı Görüntüle":"✏️ Soruları Düzenle"}),n.jsx("button",{onClick:()=>u(e),disabled:i===e,style:{backgroundColor:i===e?"#95a5a6":"#9b59b6",color:"white",border:"none",padding:"8px 15px",borderRadius:"5px",cursor:i===e?"wait":"pointer",fontWeight:"bold"},children:i===e?"⏳ İndiriliyor...":"📄 PDF İndir"}),n.jsx("button",{onClick:()=>f(e),style:{backgroundColor:"#e74c3c",color:"white",border:"none",padding:"8px 15px",borderRadius:"5px",cursor:"pointer",fontWeight:"bold"},children:"🗑️ Sil"})]})]},e)})())}),n.jsx("button",{onClick:()=>{const t=localStorage.getItem("edumath_user");let e="/student-dashboard";if(t)try{JSON.parse(t).role==="teacher"&&(e="/teacher-dashboard")}catch{}o(e)},style:{marginTop:"30px",background:"none",border:"none",color:"#666",cursor:"pointer",textDecoration:"underline"},children:"← Panele Dön"})]})};export{R as default};
